<?php
/* Copyright (C) 2005-2012	Regis Houssin	<regis.houssin@inodbox.com>
 *
 * This file is a custom PDF model for Dolibarr Intervention module.
 * It is designed to replicate a specific visual layout, display intervention lines,
 * and automatically calculate header fields from line details.
 */

require_once DOL_DOCUMENT_ROOT.'/core/modules/fichinter/modules_fichinter.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/company.lib.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/pdf.lib.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/date.lib.php';

class pdf_perso extends ModelePDFFicheinter
{
    public $db;
    public $name;
    public $description;
    public $type;
    public $version = 'dolibarr';

    public function __construct($db)
    {
        global $langs, $mysoc;
        $this->db = $db;
        $this->name = 'perso';
        $this->description = "PV Intervention Final (Calcul Automatique)";
        $this->type = 'pdf';
        $formatarray = pdf_getFormat();
        $this->page_largeur = $formatarray['width'];
        $this->page_hauteur = $formatarray['height'];
        $this->format = array($this->page_largeur, $this->page_hauteur);
        $this->marge_gauche = 10;
        $this->marge_droite = 10;
        $this->marge_haute = 10;
        $this->marge_basse = 10;
        $this->emetteur = $mysoc;
    }

    public function write_file($object, $outputlangs, $srctemplatepath = '', $hidedetails = 0, $hidedesc = 0, $hideref = 0)
    {
        global $conf, $langs, $user;

        if (!is_object($outputlangs)) {
            $outputlangs = $langs;
        }
        $outputlangs->loadLangs(array("main", "interventions", "companies", "users"));

        // --- AUTOMATIC CALCULATIONS FROM LINES ---
        $earliest_start_timestamp = null;
        $total_duration_seconds = 0;

        if (!empty($object->lines)) {
            $start_timestamps = array();
            foreach ($object->lines as $line) {
                $total_duration_seconds += $line->duration;
                if (!empty($line->datei)) {
                    $start_timestamps[] = $line->datei;
                }
            }
            if (!empty($start_timestamps)) {
                $earliest_start_timestamp = min($start_timestamps);
            }
        }
        $final_end_timestamp = $earliest_start_timestamp ? $earliest_start_timestamp + $total_duration_seconds : null;
        // --- END OF CALCULATIONS ---


        $pdf = pdf_getInstance($this->format);
        $pdf->SetAutoPageBreak(true, $this->marge_basse);
        $pdf->SetFont(pdf_getPDFFont($outputlangs));
        $pdf->SetMargins($this->marge_gauche, $this->marge_haute, $this->marge_droite);
        $pdf->AddPage();

        $this->_pagehead_perso($pdf, $object, $outputlangs);

        // --- BOXED TITLE ---
        $pdf->SetY(35);
        $pdf->SetFont('', 'B', 12);
        // Set a blue color for the title bar background
        $pdf->SetFillColor(70, 130, 180); // SteelBlue color
        $pdf->SetTextColor(255, 255, 255);
        $title = $outputlangs->transnoentities("INTERVENTION PREVENTIVE").' : ' . $outputlangs->convToOutputCharset($object->ref);
        $pdf->Cell(0, 10, $title, 0, 1, 'C', true);
        $pdf->SetTextColor(0, 0, 0); // Reset text color
        $pdf->Ln(10);

        // --- DETAILS TABLE (with calculated values and blue labels) ---
        $pdf->SetFont('', '', 10);
        $col1_x = $this->marge_gauche;
        $col2_x = $this->marge_gauche + 95;
        $line_height = 6;
        $current_y = $pdf->GetY();
        
        $object->fetch_optionals();

        // Define blue color for labels
        $blue_color = array(65, 105, 225); // RoyalBlue

        // Column 1
        $pdf->SetXY($col1_x, $current_y);
        $pdf->SetFont('', 'B'); $pdf->SetTextColor($blue_color[0], $blue_color[1], $blue_color[2]); $pdf->Cell(40, $line_height, $outputlangs->transnoentities("Date").' :');
        $pdf->SetFont('', ''); $pdf->SetTextColor(0,0,0); $pdf->Cell(55, $line_height, dol_print_date($earliest_start_timestamp, 'daytext', false, $outputlangs));
        $pdf->Ln($line_height);
        $pdf->SetX($col1_x);
        $pdf->SetFont('', 'B'); $pdf->SetTextColor($blue_color[0], $blue_color[1], $blue_color[2]); $pdf->Cell(40, $line_height, $outputlangs->transnoentities("Heure de début").' :');
        $pdf->SetFont('', ''); $pdf->SetTextColor(0,0,0); $pdf->Cell(55, $line_height, ($earliest_start_timestamp ? date('H\hi', $earliest_start_timestamp) : ''));
        $pdf->Ln($line_height);
        $pdf->SetX($col1_x);

        $intervenant_name = (isset($object->array_options['options_intervenant']) ? $object->array_options['options_intervenant'] : '');
        $pdf->SetFont('', 'B'); $pdf->SetTextColor($blue_color[0], $blue_color[1], $blue_color[2]); $pdf->Cell(40, $line_height, $outputlangs->transnoentities("Intervenant").' :');
        $pdf->SetFont('', ''); $pdf->SetTextColor(0,0,0); $pdf->Cell(55, $line_height, $outputlangs->convToOutputCharset($intervenant_name));

        $pdf->Ln($line_height);
        $pdf->SetX($col1_x);
        $pdf->SetFont('', 'B'); $pdf->SetTextColor($blue_color[0], $blue_color[1], $blue_color[2]); $pdf->Cell(40, $line_height, $outputlangs->transnoentities("Numéro du marché").' :');
        $pdf->SetFont('', ''); $pdf->SetTextColor(0,0,0); $pdf->Cell(55, $line_height, (isset($object->array_options['options_numeromarche']) ? $outputlangs->convToOutputCharset($object->array_options['options_numeromarche']) : ''));

        // Column 2
        $pdf->SetXY($col2_x, $current_y);
        $pdf->SetFont('', 'B'); $pdf->SetTextColor($blue_color[0], $blue_color[1], $blue_color[2]); $pdf->Cell(40, $line_height, $outputlangs->transnoentities("Lieu").' :');
        $pdf->SetFont('', ''); $pdf->SetTextColor(0,0,0); $pdf->Cell(55, $line_height, (isset($object->array_options['options_lieu']) ? $outputlangs->convToOutputCharset($object->array_options['options_lieu']) : ''));
        $pdf->Ln($line_height);
        $pdf->SetX($col2_x);
        $pdf->SetFont('', 'B'); $pdf->SetTextColor($blue_color[0], $blue_color[1], $blue_color[2]); $pdf->Cell(40, $line_height, $outputlangs->transnoentities("Heure de fin").' :');
        $pdf->SetFont('', ''); $pdf->SetTextColor(0,0,0); $pdf->Cell(55, $line_height, ($final_end_timestamp ? date('H\hi', $final_end_timestamp) : ''));
        $pdf->Ln($line_height);
        $pdf->SetX($col2_x);
        $pdf->SetFont('', 'B'); $pdf->SetTextColor($blue_color[0], $blue_color[1], $blue_color[2]); $pdf->Cell(40, $line_height, $outputlangs->transnoentities("Trimestre").' :');
        $pdf->SetFont('', ''); $pdf->SetTextColor(0,0,0); $pdf->Cell(55, $line_height, (isset($object->array_options['options_trimestre']) ? $outputlangs->convToOutputCharset($object->array_options['options_trimestre']) : ''));

        $pdf->SetTextColor(0,0,0); // Reset color to black for the rest of the document
        $pdf->SetY($pdf->GetY() + 10);
        
        // --- OBJET & TACHES ---
        $pdf->Ln(5); // ADDED SPACE BEFORE OBJET
        $pdf->SetFont('', 'B', 11);
        $pdf->SetTextColor($blue_color[0], $blue_color[1], $blue_color[2]);
        $pdf->Cell(0, 7, $outputlangs->transnoentities("Objet"), 0, 1, 'L');
        $pdf->SetTextColor(0,0,0);
        $pdf->Line($pdf->GetX(), $pdf->GetY(), $pdf->GetX() + 15, $pdf->GetY());
        $pdf->Ln(2);
        $pdf->SetFont('', '', 10);
        
        $objet_text = (isset($object->array_options['options_objet']) ? $object->array_options['options_objet'] : '');
        $pdf->MultiCell(0, 5, $outputlangs->convToOutputCharset($objet_text), 0, 'L');
        
        $pdf->Ln(8);

        $pdf->SetFont('', 'B', 11);
        $pdf->SetTextColor($blue_color[0], $blue_color[1], $blue_color[2]);
        $pdf->Cell(0, 7, $outputlangs->transnoentities("Taches de maintenance effectuées"), 0, 1, 'L');
        $pdf->SetTextColor(0,0,0);
        $pdf->Line($pdf->GetX(), $pdf->GetY(), $pdf->GetX() + 62, $pdf->GetY());
        $pdf->Ln(2);
        
        if (!empty($object->lines)) {
            foreach ($object->lines as $line) {
                $pdf->SetFont('', 'B', 10);
                $x_pos = $pdf->GetX();
                $y_pos = $pdf->GetY();
                $pdf->MultiCell(140, 5, '- '.$outputlangs->convToOutputCharset($line->desc), 0, 'L');
                $end_y_pos = $pdf->GetY();
                $pdf->SetXY($x_pos + 140, $y_pos);
                $pdf->SetFont('', '', 9);
                $date_str = dol_print_date($line->datei, 'dayhour', false, $outputlangs);
                $duration_str = convertSecondToTime($line->duration);
                $pdf->MultiCell(0, 5, $outputlangs->transnoentities("Duration") . ": " . $duration_str, 0, 'R');
                $pdf->SetY(max($end_y_pos, $pdf->GetY()) + 2);
            }
        }
        
        // --- SIGNATURE AREA & FOOTER ---
        $pdf->SetY(-40);
        $pdf->SetFont('', 'B', 10);
        $pdf->SetTextColor($blue_color[0], $blue_color[1], $blue_color[2]);
        $half_page = ($this->page_largeur - $this->marge_gauche - $this->marge_droite) / 2;
        $pdf->Cell($half_page, 7, $outputlangs->transnoentities("Signature HTBS"), 0, 0, 'L');
        $pdf->Cell($half_page, 7, $outputlangs->transnoentities("Signature client"), 0, 1, 'L');
        
        
        // --- FILE OUTPUT ---
        $objectref = dol_sanitizeFileName($object->ref);
        $dir = $conf->ficheinter->dir_output . "/" . $objectref;
        if (!file_exists($dir)) dol_mkdir($dir);
        $file = $dir . "/" . $objectref . ".pdf";
        $pdf->Output($file, 'F');
        if (!empty($conf->global->MAIN_UMASK)) @chmod($file, octdec($conf->global->MAIN_UMASK));
        return 1;
    }

    protected function _pagehead_perso(&$pdf, $object, $outputlangs) {
        global $conf;
        $object->fetch_thirdparty();
        if (!empty($this->emetteur->logo)) {
            $mylogo = $conf->mycompany->multidir_output[$this->emetteur->entity] . "/logos/" . $this->emetteur->logo;
            if (is_readable($mylogo)) {
                $height = pdf_getHeightForLogo($mylogo);
                $pdf->Image($mylogo, $this->marge_gauche, $this->marge_haute, 0, $height);
            }
        }
        if (!empty($object->thirdparty->logo_file)) {
            $clientlogo = $conf->thirdparty->multidir_output[$object->thirdparty->entity] . '/' . $object->thirdparty->id . '/logos/' . $object->thirdparty->logo_file;
            if (is_readable($clientlogo)) {
                $height = pdf_getHeightForLogo($clientlogo);
                $width = pdf_getWidthForLogo($clientlogo);
                $pdf->Image($clientlogo, $this->page_largeur - $this->marge_droite - $width, $this->marge_haute, 0, $height);
            }
        }
    }
}

// WORKAROUND: Add helper functions here to make the file self-sufficient
if (!function_exists('pdf_getHeightForLogo')) {
    function pdf_getHeightForLogo($logo, $dpia = 72) {
        $height = 20; $imgsize = dol_getimagesize($logo);
        if ($imgsize) { $height = round($imgsize[1] * 25.4 / $dpia); }
        if ($height > 25) { $height = 25; }
        return $height;
    }
}
if (!function_exists('pdf_getWidthForLogo')) {
    function pdf_getWidthForLogo($logo, $dpia = 72) {
        $width = 0; $imgsize = dol_getimagesize($logo);
        if ($imgsize) {
            $height = round($imgsize[1] * 25.4 / $dpia);
            if ($height > 25) { $ratio = 25 / $height; $width = round($imgsize[0] * 25.4 / $dpia * $ratio); }
        }
        return $width;
    }
}